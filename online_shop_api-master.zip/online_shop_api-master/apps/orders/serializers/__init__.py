from orders.serializers.product import ProductModelSerializer
from orders.serializers.product_handbook import CompanyModelSerializer, ImagesModelSerializer, RatingModelSerializer, \
    CommentsModelSerializer, BasketModelSerializer, OrderModelSerializer, PaymentsModelSerializer, \
    CommentsListModelSerializer, CategoryModelSerializer, SubCategoryModelSerializer
