from orders.views.product import ProductReadOnlyModelViewSet
from orders.views.product_handbook import CompanyReadOnlyModelViewSet, RatingModelViewSet, BasketModelViewSet, \
    OrderReadOnlyViewSet, PaymentsModelViewSet, ImagesModelListAPIView, ImagesModelDetailAPIView, \
    CommentsListAPIView, CategoryReadOnlyModelViewSet, SubCategoryReadOnlyModelViewSet
