from users.views.UserInfo import GetMeApiView
from users.views.activate_account import ActivateUserApiView
from users.views.change_password import ChangePasswordApiView
from users.views.forgot_password import ForgotPasswordApiView
from users.views.login import CustomTokenObtainPairView
from users.views.register import UserCreateApiView
